package com.assign.jdbc;

import java.sql.SQLException;
import java.util.Scanner;

public class Main {
	
	
public static void main(String[] args) throws SQLException {
	
	DbOperation.createTable();
	
	DbOperation.insertData();
DbOperation.printContentOfTable();
DbOperation.userDemand();
}
}
